package com.salesianostriana.dam.registro_de_jornada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistroDeJornadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
