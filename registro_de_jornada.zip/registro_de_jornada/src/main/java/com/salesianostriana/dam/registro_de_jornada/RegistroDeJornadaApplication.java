package com.salesianostriana.dam.registro_de_jornada;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistroDeJornadaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistroDeJornadaApplication.class, args);
	}

}
