//package com.salesianostriana.dam.registro_de_jornada.model;
//
//public record DepartamentoResponse(
//        Long id,
//        String nombre,
//        Double presupuesto
//) {
//    public static DepartamentoResponse fromDepartamento(Departamento departamento) {
//        return new DepartamentoResponse(
////                departamento.getDepartamento_id(),
////                departamento.getNombre(),
////                departamento.getPresupuesto().doubleValue()
//        //);
//    //}
//}
