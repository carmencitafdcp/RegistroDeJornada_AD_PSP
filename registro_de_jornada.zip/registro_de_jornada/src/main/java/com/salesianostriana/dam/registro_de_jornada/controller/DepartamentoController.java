package com.salesianostriana.dam.registro_de_jornada.controller;

public class DepartamentoController {
}
